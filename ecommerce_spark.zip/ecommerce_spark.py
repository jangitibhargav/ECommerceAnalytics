import os
import sys
import subprocess

os.environ['PYSPARK_PYTHON'] = sys.executable
os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable
os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'
os.environ['HADOOP_HOME'] = 'C:\\hadoop'
os.environ['HADOOP_CONF_DIR'] = 'C:\\hadoop\\etc\\hadoop'

# Set JAVA_HOME
try:
    result = subprocess.run(['where', 'java'], capture_output=True, text=True, shell=True)
    if result.returncode == 0:
        java_path = result.stdout.strip().split('\n')[0]
        java_home = os.path.dirname(os.path.dirname(java_path))
        os.environ['JAVA_HOME'] = java_home
        print(f"Found Java at: {java_home}")
except Exception as e:
    print(f"Could not find Java: {e}")

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum as _sum, count, avg, max as _max, min as _min, date_format, when, desc, asc, row_number, datediff
from pyspark.sql.window import Window

os.makedirs("spark_output", exist_ok=True)

spark = SparkSession.builder \
    .appName("ECommerceAnalytics") \
    .config("spark.driver.host", "127.0.0.1") \
    .config("spark.driver.bindAddress", "127.0.0.1") \
    .config("spark.hadoop.io.native.lib.available", "false") \
    .config("spark.sql.execution.arrow.pyspark.enabled", "false") \
    .getOrCreate()

try:
    # Load data from correct path
    data_path = "ecommerce_spark/dashboard"
    customers = spark.read.csv(f"{data_path}/customers_large.csv", header=True, inferSchema=True)
    products = spark.read.csv(f"{data_path}/products_large.csv", header=True, inferSchema=True)
    orders = spark.read.csv(f"{data_path}/orders_large.csv", header=True, inferSchema=True)
    payments = spark.read.csv(f"{data_path}/payments_large.csv", header=True, inferSchema=True)
    shipping = spark.read.csv(f"{data_path}/shipping_large.csv", header=True, inferSchema=True)
    
    # 1. Monthly Sales Analysis
    monthly_sales = orders.groupBy(date_format("order_date","yyyy-MM").alias("month")) \
                          .agg(_sum("total_amount").alias("monthly_sales")) \
                          .orderBy("month")
    monthly_sales.toPandas().to_csv("spark_output/monthly_sales.csv", index=False)
    
    # 2. Top Products by Revenue
    top_products = orders.join(products, "product_id") \
                         .groupBy("product_id","name","category") \
                         .agg(_sum("total_amount").alias("revenue")) \
                         .orderBy(col("revenue").desc()).limit(50)
    top_products.toPandas().to_csv("spark_output/top_products.csv", index=False)
    
    # 3. Customer Segmentation
    customer_revenue = orders.join(customers, "customer_id") \
                            .groupBy("customer_id", "name") \
                            .agg(_sum("total_amount").alias("total_revenue")) \
                            .withColumn("segment", 
                                when(col("total_revenue") >= 1000, "Platinum")
                                .when(col("total_revenue") >= 500, "Gold")
                                .when(col("total_revenue") >= 100, "Silver")
                                .otherwise("Bronze"))
    customer_revenue.toPandas().to_csv("spark_output/customer_segments.csv", index=False)
    
    # 4. Category Performance
    category_performance = orders.join(products, "product_id") \
                                .groupBy("category") \
                                .agg(_sum("total_amount").alias("revenue"),
                                     count("order_id").alias("orders")) \
                                .orderBy(col("revenue").desc())
    category_performance.toPandas().to_csv("spark_output/category_performance.csv", index=False)
    
    # 5. Payment Method Analysis
    payment_analysis = payments.groupBy("payment_type") \
                              .agg(count("payment_id").alias("count"),
                                   _sum("transaction_amount").alias("total_amount")) \
                              .orderBy(col("count").desc())
    payment_analysis.toPandas().to_csv("spark_output/payment_analysis.csv", index=False)
    
    # 6. Top Products per Category
    window = Window.partitionBy("category").orderBy(col("revenue").desc())
    category_top_products = orders.join(products, "product_id") \
                                 .groupBy("category", "name") \
                                 .agg(_sum("total_amount").alias("revenue")) \
                                 .withColumn("rank", row_number().over(window)) \
                                 .filter(col("rank") <= 5) \
                                 .orderBy("category", "rank")
    category_top_products.toPandas().to_csv("spark_output/category_top_products.csv", index=False)
    
    # 7. Customer Demographics
    customer_demographics = customers.groupBy("country") \
                                   .agg(count("customer_id").alias("customer_count")) \
                                   .orderBy(col("customer_count").desc())
    customer_demographics.toPandas().to_csv("spark_output/customer_demographics.csv", index=False)
    
    # 8. Shipping Performance
    # Join orders and shipping to calculate delivery days
    shipping_with_orders = orders.alias("o").join(shipping.alias("s"), "order_id") \
                                .withColumn("delivery_days", 
                                    datediff(col("s.delivery_date"), col("o.order_date")))
    
    shipping_performance = shipping_with_orders.groupBy("s.shipping_type") \
                                              .agg(avg("delivery_days").alias("avg_delivery_days"),
                                                   count("s.shipping_id").alias("shipment_count")) \
                                              .orderBy("avg_delivery_days")
    shipping_performance.toPandas().to_csv("spark_output/shipping_performance.csv", index=False)
    
    # 9. Repeat Customer Analysis
    repeat_customers = orders.join(customers, "customer_id") \
                            .groupBy("customer_id", "name") \
                            .agg(count("order_id").alias("order_count"),
                                 count("product_id").alias("products_purchased")) \
                            .filter(col("order_count") > 1) \
                            .orderBy(col("order_count").desc())
    repeat_customers.toPandas().to_csv("spark_output/repeat_customers.csv", index=False)
    
    print("PySpark processing completed successfully!")
    print("Generated analytics files in spark_output/ directory")
    
except Exception as e:
    print(f"Error: {e}")
finally:
    spark.stop()