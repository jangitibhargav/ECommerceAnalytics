import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Page config
st.set_page_config(page_title="E-Commerce Analytics Dashboard", layout="wide")

# Suppress warnings
import warnings
warnings.filterwarnings('ignore')

# Title
st.title("🛒 E-Commerce Analytics Dashboard")
st.markdown("---")

# Load data
@st.cache_data
def load_data():
    try:
        monthly_sales = pd.read_csv("spark_output/monthly_sales.csv")
        top_products = pd.read_csv("spark_output/top_products.csv")
        customer_segments = pd.read_csv("spark_output/customer_segments.csv")
        category_performance = pd.read_csv("spark_output/category_performance.csv")
        payment_analysis = pd.read_csv("spark_output/payment_analysis.csv")
        category_top_products = pd.read_csv("spark_output/category_top_products.csv")
        customer_demographics = pd.read_csv("spark_output/customer_demographics.csv")
        shipping_performance = pd.read_csv("spark_output/shipping_performance.csv")
        repeat_customers = pd.read_csv("spark_output/repeat_customers.csv")
        
        return {
            'monthly_sales': monthly_sales,
            'top_products': top_products,
            'customer_segments': customer_segments,
            'category_performance': category_performance,
            'payment_analysis': payment_analysis,
            'category_top_products': category_top_products,
            'customer_demographics': customer_demographics,
            'shipping_performance': shipping_performance,
            'repeat_customers': repeat_customers
        }
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return None

data = load_data()

if data:
    # Sidebar filters
    st.sidebar.header("📊 Dashboard Filters")
    
    # Category filter
    categories = data['category_performance']['category'].unique()
    selected_categories = st.sidebar.multiselect("Select Categories", categories, default=categories)
    
    # Top N products filter
    top_n = st.sidebar.slider("Top N Products", 5, 50, 20)
    
    # KPIs Row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        total_revenue = data['monthly_sales']['monthly_sales'].sum()
        st.metric("Total Revenue", f"${total_revenue:,.0f}")
    
    with col2:
        total_customers = len(data['customer_segments'])
        st.metric("Total Customers", f"{total_customers:,}")
    
    with col3:
        avg_order_value = total_revenue / data['category_performance']['orders'].sum()
        st.metric("Avg Order Value", f"${avg_order_value:.2f}")
    
    with col4:
        total_orders = data['category_performance']['orders'].sum()
        st.metric("Total Orders", f"{total_orders:,}")
    
    st.markdown("---")
    
    # Row 1: Monthly Sales and Customer Segments
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📈 Monthly Sales Trend")
        fig_monthly = px.line(data['monthly_sales'], x='month', y='monthly_sales',
                             title="Monthly Sales Performance",
                             labels={'monthly_sales': 'Sales ($)', 'month': 'Month'})
        fig_monthly.update_traces(line_color='#1f77b4', line_width=3)
        st.plotly_chart(fig_monthly, use_container_width=True)
    
    with col2:
        st.subheader("👥 Customer Segmentation")
        segment_counts = data['customer_segments']['segment'].value_counts()
        fig_segments = px.pie(values=segment_counts.values, names=segment_counts.index,
                             title="Customer Distribution by Segment",
                             color_discrete_sequence=['#ff7f0e', '#2ca02c', '#d62728', '#9467bd'])
        st.plotly_chart(fig_segments, use_container_width=True)
    
    # Row 2: Category Performance and Payment Analysis
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🏷️ Category Performance")
        filtered_categories = data['category_performance'][
            data['category_performance']['category'].isin(selected_categories)
        ]
        fig_category = px.bar(filtered_categories, x='category', y='revenue',
                             title="Revenue by Category",
                             labels={'revenue': 'Revenue ($)', 'category': 'Category'},
                             color='revenue', color_continuous_scale='viridis')
        st.plotly_chart(fig_category, use_container_width=True)
    
    with col2:
        st.subheader("💳 Payment Method Analysis")
        fig_payment = px.bar(data['payment_analysis'], x='payment_type', y='count',
                            title="Payment Method Usage",
                            labels={'count': 'Number of Transactions', 'payment_type': 'Payment Type'},
                            color='total_amount', color_continuous_scale='plasma')
        st.plotly_chart(fig_payment, use_container_width=True)
    
    # Row 3: Top Products and Shipping Performance
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🏆 Top Products by Revenue")
        top_products_filtered = data['top_products'].head(top_n)
        fig_products = px.bar(top_products_filtered, x='revenue', y='name',
                             orientation='h', title=f"Top {top_n} Products",
                             labels={'revenue': 'Revenue ($)', 'name': 'Product'},
                             color='category', height=600)
        fig_products.update_layout(yaxis={'categoryorder': 'total ascending'})
        st.plotly_chart(fig_products, use_container_width=True)
    
    with col2:
        st.subheader("🚚 Shipping Performance")
        fig_shipping = px.scatter(data['shipping_performance'], 
                                 x='avg_delivery_days', y='shipment_count',
                                 size='shipment_count', color='shipping_type',
                                 title="Delivery Days vs Shipment Volume",
                                 labels={'avg_delivery_days': 'Avg Delivery Days', 
                                        'shipment_count': 'Shipment Count',
                                        'shipping_type': 'Shipping Type'})
        st.plotly_chart(fig_shipping, use_container_width=True)
    
    # Row 4: Customer Demographics and Category Top Products
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🌍 Customer Demographics")
        top_countries = data['customer_demographics'].head(10)
        fig_demo = px.bar(top_countries, x='customer_count', y='country',
                         orientation='h', title="Top 10 Countries by Customer Count",
                         labels={'customer_count': 'Customer Count', 'country': 'Country'},
                         color='customer_count', color_continuous_scale='blues')
        fig_demo.update_layout(yaxis={'categoryorder': 'total ascending'})
        st.plotly_chart(fig_demo, use_container_width=True)
    
    with col2:
        st.subheader("🎯 Top Products by Category")
        fig_cat_products = px.sunburst(data['category_top_products'], 
                                      path=['category', 'name'], values='revenue',
                                      title="Revenue Distribution by Category & Product")
        st.plotly_chart(fig_cat_products, use_container_width=True)
    
    # Customer Analysis Section
    st.markdown("---")
    st.subheader("👤 Customer Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🔄 Top Repeat Customers")
        top_repeat = data['repeat_customers'].head(15)[['customer_id', 'name', 'order_count', 'products_purchased']]
        st.dataframe(top_repeat, use_container_width=True)
    
    with col2:
        st.subheader("🔍 Customer Search")
        search_term = st.text_input("Search by Customer ID or Name:")
        if search_term:
            search_results = data['customer_segments'][
                (data['customer_segments']['customer_id'].astype(str).str.contains(search_term, case=False)) |
                (data['customer_segments']['name'].str.contains(search_term, case=False))
            ][['customer_id', 'name', 'total_revenue', 'segment']]
            if not search_results.empty:
                st.dataframe(search_results, use_container_width=True)
            else:
                st.info("No customers found matching your search.")
    
    # Data Tables Section
    st.markdown("---")
    st.subheader("📋 Detailed Data Tables")
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs(["Monthly Sales", "Top Products", "Customer Segments", "Repeat Customers", "Category Performance"])
    
    with tab1:
        st.dataframe(data['monthly_sales'], use_container_width=True)
    
    with tab2:
        st.dataframe(data['top_products'].head(20), use_container_width=True)
    
    with tab3:
        st.subheader("Top Customers by Segment")
        top_customers = data['customer_segments'].nlargest(20, 'total_revenue')[['customer_id', 'name', 'total_revenue', 'segment']]
        st.dataframe(top_customers, use_container_width=True)
    
    with tab4:
        st.dataframe(data['repeat_customers'], use_container_width=True)
    
    with tab5:
        st.dataframe(data['category_performance'], use_container_width=True)

else:
    st.error("❌ Could not load data. Please ensure the PySpark script has been run and CSV files exist in spark_output/ directory.")
    st.info("💡 Run: `python ecommerce_spark.py` first to generate the required data files.")